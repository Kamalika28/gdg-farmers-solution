import { getRecommendations } from './SoilService';
import { SoilData, SoilRecommendation } from '../models/SoilModel';

describe('getRecommendations', () => {
  it('should return correct recommendations for sandy soil', () => {
    const soilData: SoilData = {
      soilType: 'Sandy',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['carrots', 'lettuce', 'peppers', 'tomatoes', 'sweet potatoes', 'watermelons'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should return correct recommendations for clay soil', () => {
    const soilData: SoilData = {
      soilType: 'Clay',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['broccoli', 'cabbage', 'Brussels sprouts', 'lavender', 'sunflowers'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should return correct recommendations for loamy soil', () => {
    const soilData: SoilData = {
      soilType: 'Loamy',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['beans', 'peas', 'corn', 'wheat', 'carrots', 'onions'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });
  
  it('should return correct recommendations for silty soil', () => {
    const soilData: SoilData = {
      soilType: 'Silty',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['leafy greens', 'berries', 'some fruits', 'celery', 'cucumber'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should return correct recommendations for peaty soil', () => {
    const soilData: SoilData = {
      soilType: 'Peaty',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['blueberries', 'cranberries', 'rhubarb', 'gooseberries'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should return correct recommendations for chalky soil', () => {
    const soilData: SoilData = {
      soilType: 'Chalky',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['spinach', 'beets', 'some flowering plants', 'peas', 'strawberries'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should handle unknown soil type', () => {
    const soilData: SoilData = {
      soilType: 'Unknown',
      soilMoisture: 60,
      phLevel: 6.5,
    };
    const expectedRecommendations: string[] = ['Unknown soil type'];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should refine recommendations based on moisture level (low)', () => {
    const soilData: SoilData = {
      soilType: 'Loamy',
      soilMoisture: 30,
      phLevel: 6.5,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('rhubarb');
    expect(result.recommendations).not.toContain('cucumber');
    expect(result.recommendations).not.toContain('celery');
  });

  it('should refine recommendations based on moisture level (medium)', () => {
    const soilData: SoilData = {
      soilType: 'Loamy',
      soilMoisture: 45,
      phLevel: 6.5,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('onions');
    expect(result.recommendations).not.toContain('gooseberries');
  });

  it('should refine recommendations based on moisture level (high)', () => {
    const soilData: SoilData = {
      soilType: 'Sandy',
      soilMoisture: 75,
      phLevel: 6.5,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('lettuce');
    expect(result.recommendations).not.toContain('sweet potatoes');
    expect(result.recommendations).not.toContain('lavender');
    expect(result.recommendations).not.toContain('sunflowers');
    expect(result.recommendations).not.toContain('strawberries');
  });

  it('should refine recommendations based on moisture level (very high)', () => {
    const soilData: SoilData = {
      soilType: 'Sandy',
      soilMoisture: 85,
      phLevel: 6.5,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    console.log('Recommendations before filtering (very high moisture):', getRecommendations(soilData).recommendations);
    console.log('Recommendations after filtering (very high moisture):', result.recommendations);
    expect(result.recommendations).not.toContain('carrots');
    expect(result.recommendations).not.toContain('peas');
    expect(result.recommendations).not.toContain('watermelons');
    expect(result.recommendations).not.toContain('beans');
    expect(result.recommendations).not.toContain('wheat');
  });

  it('should refine recommendations based on pH level (low)', () => {
    const soilData: SoilData = {
      soilType: 'Loamy',
      soilMoisture: 60,
      phLevel: 4.5,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('peas');
    expect(result.recommendations).not.toContain('onions');
    expect(result.recommendations).not.toContain('spinach');
    expect(result.recommendations).not.toContain('beets');
    expect(result.recommendations).not.toContain('sunflowers');
    expect(result.recommendations).not.toContain('watermelons');
  });

  it('should refine recommendations based on pH level (slightly low)', () => {
    const soilData: SoilData = {
      soilType: 'Chalky',
      soilMoisture: 60,
      phLevel: 5.2,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('strawberries');
  });

  it('should refine recommendations based on pH level (high)', () => {
    const soilData: SoilData = {
      soilType: 'Loamy',
      soilMoisture: 60,
      phLevel: 7.2,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).not.toContain('carrots');
    expect(result.recommendations).not.toContain('cucumber');
    expect(result.recommendations).not.toContain('celery');
  });

  it('should refine recommendations based on pH level (very high)', () => {
    const soilData: SoilData = {
      soilType: 'Peaty',
      soilMoisture: 60,
      phLevel: 7.8,
    };
    const expectedRecommendations: string[] = [];
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual(expectedRecommendations);
  });

  it('should return an empty array if no recommendations match after filtering', () => {
    const soilData: SoilData = {
      soilType: 'Sandy',
      soilMoisture: 90, 
      phLevel: 4.0,
    };
    const result: SoilRecommendation = getRecommendations(soilData);
    expect(result.recommendations).toEqual([]);
  });
});