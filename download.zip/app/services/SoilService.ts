import { SoilData, SoilRecommendation } from '../models/SoilModel';

export const getRecommendations = (soilData: SoilData): SoilRecommendation => {
  const { soilType, soilMoisture, phLevel } = soilData;
  let recommendations: string[] = [];

  switch (soilType) {
    case 'Sandy': // Add 'sweet potatoes', 'watermelons'
      recommendations = ['carrots', 'lettuce', 'peppers', 'tomatoes', 'sweet potatoes', 'watermelons'];
        break;
      case 'Clay': // Add 'lavender', 'sunflowers'
        recommendations = ['broccoli', 'cabbage', 'Brussels sprouts', 'lavender', 'sunflowers'];
        break;
      case 'Loamy': // Add 'carrots', 'onions'
        recommendations = ['beans', 'peas', 'corn', 'wheat', 'carrots', 'onions'];
        break;
      case 'Silty': // Add 'celery', 'cucumber'
        recommendations = ['leafy greens', 'berries', 'some fruits', 'celery', 'cucumber'];
        break;
      case 'Peaty': // Add 'rhubarb', 'gooseberries'
        recommendations = ['blueberries', 'cranberries', 'rhubarb', 'gooseberries'];
        break;
      case 'Chalky': // Add 'peas', 'strawberries'
        recommendations = ['spinach', 'beets', 'some flowering plants', 'peas', 'strawberries'];
        break;
      default:
        return { recommendations: ['Unknown soil type'] };
    }
    console.log('Initial recommendations:', recommendations);

  // Refine recommendations based on moisture level
  let filteredRecommendations = recommendations;  
  if (soilMoisture > 80) {
      filteredRecommendations = filteredRecommendations.filter(crop => !['carrots', 'peas', 'watermelons', 'beans'].includes(crop));
  } else if (soilMoisture > 70 && soilMoisture <= 80) {
      filteredRecommendations = filteredRecommendations.filter(crop => !['lettuce', 'sweet potatoes', 'lavender', 'sunflowers', 'strawberries'].includes(crop));
  } else if (soilMoisture < 50) {
      filteredRecommendations = filteredRecommendations.filter(crop => !['onions', 'gooseberries'].includes(crop));
  }

      
    recommendations = filteredRecommendations;

  console.log('Recommendations after moisture filtering:', recommendations);

  // Refine recommendations based on pH level
    let filteredRecommendationsPh = recommendations;
    console.log(`pH level before filtering: ${phLevel}`);
    console.log('Recommendations before pH filtering:', filteredRecommendationsPh);
      if (phLevel < 5.0) {
        filteredRecommendationsPh = filteredRecommendationsPh.filter(crop => !['peas','onions', 'spinach', 'beets', 'sunflowers', 'watermelons','lettuce', 'peppers', 'tomatoes', 'sweet potatoes'].includes(crop));
      } else if (phLevel < 5.5){
        filteredRecommendationsPh = filteredRecommendationsPh.filter(crop => !['strawberries'].includes(crop));
      }
     else if (phLevel > 7.5) {
        console.log('Entering pH > 7.5 filtering block');
        console.log(`phLevel inside filtering: ${phLevel}`);
        console.log('filteredRecommendationsPh before:', filteredRecommendationsPh);
        filteredRecommendationsPh = filteredRecommendationsPh.filter(crop => !['blueberries', 'cranberries', 'rhubarb', 'gooseberries'].includes(crop));
        console.log('filteredRecommendationsPh after:', filteredRecommendationsPh);
      }else if (phLevel > 7.0) {
        filteredRecommendationsPh = filteredRecommendationsPh.filter(crop => !['carrots', 'cucumber', 'celery'].includes(crop));
        if (soilType === 'Sandy' && soilMoisture > 80 && phLevel < 5.0){
          filteredRecommendationsPh = filteredRecommendationsPh.filter(()=> false);
        }
      } else if (phLevel > 7.5) {
        filteredRecommendationsPh = filteredRecommendationsPh.filter(crop => !['blueberries', 'cranberries', 'rhubarb', 'gooseberries'].includes(crop));
      }
    recommendations = filteredRecommendationsPh;
    console.log('Final recommendations (after pH filtering):', recommendations);

    return { recommendations: recommendations.length > 0 ? recommendations : [] };
};
