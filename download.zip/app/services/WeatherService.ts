const apiKey = process.env.OPENWEATHERMAP_API_KEY;

if (!apiKey) throw new Error("Missing OPENWEATHERMAP_API_KEY environment variable");

export const getCurrentWeather = async (location: string) => {
  try {
    // Geocoding API to get coordinates from location name
    const geoResponse = await fetch(
      `http://api.openweathermap.org/geo/1.0/direct?q=${location}&limit=1&appid=${apiKey}`
    );

    if (!geoResponse.ok) {
      throw new Error(`Geocoding API error: ${geoResponse.status}`);
    }

    const geoData = await geoResponse.json();

    if (!geoData || geoData.length === 0) {
      throw new Error(`Location not found: ${location}`);
    }

    const { lat, lon } = geoData[0];

    // Weather API to get weather data from coordinates
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
    );

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`);
    }

    const weatherData = await response.json();
    return weatherData;
  } catch (error) {
    console.error("Error fetching weather data:", error);
    throw error;
  }
};