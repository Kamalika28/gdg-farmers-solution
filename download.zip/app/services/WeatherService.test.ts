process.env.OPENWEATHERMAP_API_KEY = 'test-api-key';

import { getCurrentWeather } from './WeatherService';
import { WeatherData } from '../../models/WeatherModel';
jest.mock('./WeatherService');

describe('WeatherService', () => {
    it('should return predefined weather data', async () => {
        const mockedGetCurrentWeather = getCurrentWeather as jest.MockedFunction<typeof getCurrentWeather>;
        const expectedWeatherData = {
            location: 'Test Location',
            temperature: 20,
            description: 'Sunny',
        };
        mockedGetCurrentWeather.mockResolvedValue(expectedWeatherData);

        const weather = await getCurrentWeather('Test Location');
        expect(weather).toEqual(expectedWeatherData);
    });
});