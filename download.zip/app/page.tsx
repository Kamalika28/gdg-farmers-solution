 "use client";

import Link from "next/link";


const HomePage: React.FC = () => {

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-3xl font-bold mb-4">Farmer's App</h1>
        <div>
          <p className="mb-4">Welcome to the Farmer's App!</p>
          <div className="mt-4">
            <Link href="/soil"><button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2">Soil</button></Link>
            <Link href="/weather"><button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2">Weather</button></Link>
            <Link href="/schemes"><button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mr-2">Schemes</button></Link>
            <Link href="/modern-farming"><button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Modern Farming</button></Link>
          </div>
        </div>
    </div>
  );
};
export default HomePage;