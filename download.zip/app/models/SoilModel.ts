export interface SoilData {
  soilType: string;
  soilMoisture: number;
  phLevel: number;
}

export interface SoilRecommendation {
  recommendations: string[];
}