export interface Weather {
  location: string;
  temperature: number;
  description: string;
  humidity: number;
  windSpeed: number;
  suitableCrops: string[];
}