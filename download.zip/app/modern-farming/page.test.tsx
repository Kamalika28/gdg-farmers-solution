import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ModernFarmingPage from '../../app/modern-farming/page';

describe('ModernFarmingPage', () => {
  const mockFarmingTechniquesData = [
    {
      country: "TestCountry",
      techniques: [
        { title: "Technique 1", description: "Description 1" },
        { title: "Technique 2", description: "Description 2" },
      ],
    },
  ];
  beforeEach(() => {
    global.fetch = jest.fn(() =>
        Promise.resolve({
          json: () => Promise.resolve(mockFarmingTechniquesData),
        })
      ) as jest.Mock;
  });
  it('renders the component', () => {
      render(<ModernFarmingPage />);
      expect(screen.getByText('Modern Farming Techniques')).toBeInTheDocument();
  });

  it('displays modern farming techniques', async () => {
    const mockData = [
    render(<ModernFarmingPage/>);
      expect(await screen.findByText('TestCountry')).toBeInTheDocument();
      expect(screen.getByText('Technique 1')).toBeInTheDocument();
      expect(screen.getByText('Description 1')).toBeInTheDocument();
      expect(screen.getByText('Technique 2')).toBeInTheDocument();
      expect(screen.getByText('Description 2')).toBeInTheDocument();
  });
});