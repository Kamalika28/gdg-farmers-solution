"use client";

import styles from "./ModernFarming.module.css";
import { useState, useEffect } from "react";

interface Technique {
  title: string;
  description: string;
}

interface CountryData {
  country: string;
  techniques: Technique[];
}

const ModernFarmingPage = () => {
  const [modernFarmingTechniques, setModernFarmingTechniques] = useState<
    CountryData[]
  >([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch("/modernFarming.json");
        if (!response.ok) {
          throw new Error("Failed to fetch modern farming techniques data");
        }
        const data: CountryData[] = await response.json();
        setModernFarmingTechniques(data);
      } catch (error) {
        console.error(
          "Error fetching modern farming techniques data:",
          error
        );
        // Handle error appropriately
      }
    };

    fetchData();
  }, []);

  return (
    <div>
      <h1>Modern Farming Techniques</h1>
      {modernFarmingTechniques.map((countryData, countryIndex) => {
        const sanitizedCountry = countryData.country.toLowerCase().replace(/[^a-z0-9-]/g, "-");
        return (
        <div key={countryIndex} className={`${styles[`${sanitizedCountry}-section`]}`}>
          <h2>{countryData.country}</h2>
          {countryData.techniques.map((technique, techniqueIndex) => (
            <div key={techniqueIndex}>
              <h3>{technique.title}</h3>
              <p>{technique.description}</p>
            </div>
          ))}
        </div>
      )
      })}
    </div>
  );
};

export default ModernFarmingPage;