"use client";

import { useState } from "react";
import { Weather } from "../models/WeatherModel";
import { getCurrentWeather } from "../services/WeatherService";

const WeatherScreen = () => {
  const [location, setLocation] = useState("");
  const [weather, setWeather] = useState<Weather | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const getWeatherContainerStyle = (description: string) => {
    const baseStyle = {
      padding: '20px',
      fontFamily: 'sans-serif',
    };

    if (description.toLowerCase().includes('sun') || description.toLowerCase().includes('clear')) {
      return {
        ...baseStyle,
        backgroundColor: '#FFD700', // Gold
      };
    } else if (description.toLowerCase().includes('cloud')) {
      return {
        ...baseStyle,
        backgroundColor: '#B0C4DE', // Light Steel Blue
      };
    } else if (description.toLowerCase().includes('rain') || description.toLowerCase().includes('drizzle')) {
      return {
        ...baseStyle,
        backgroundColor: '#1E90FF', // Dodger Blue
      };
    } else if (description.toLowerCase().includes('snow')) {
        return { ...baseStyle, backgroundColor: '#F0F8FF' };//aliceblue
      }
    return { ...baseStyle, backgroundColor: '#F0F8FF' }; // Default: Alice Blue
  };

  const getSuitableCrops = (temperature: number, humidity: number) => {
    let crops: string[] = [];

    // Temperature-based rules
    if (temperature < 15) {
      crops = ['Spinach', 'Lettuce'];
    } else if (temperature >= 15 && temperature < 20) {
      crops = ['Wheat', 'Potatoes', 'Lettuce', 'Spinach'];
    } else if (temperature >= 20 && temperature < 25) {
      crops = ['Rice', 'Wheat', 'Corn', 'Soybeans', 'Cotton', 'Tomatoes', 'Peppers', 'Pumpkins'];
    } else if (temperature >= 25 && temperature < 30) {
      crops = ['Rice', 'Corn', 'Soybeans', 'Cotton', 'Sugarcane', 'Cucumbers', 'Peppers', 'Pumpkins', 'Watermelons'];
    } else if (temperature >= 30) {
      crops = ['Sorghum', 'Millet', 'Watermelons'];
    }

    // Humidity-based refinements
    if (humidity < 50) {
      crops = crops.filter(crop => !['Rice', 'Cucumbers'].includes(crop));
    }
    else if (humidity >= 80)
    {
      crops = crops.filter(crop => !['Cotton', 'Wheat', 'Peppers','Pumpkins','Watermelons'].includes(crop));
    }

    return crops;
  };









  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) return;

    setLoading(true);
    setError(null);
    setWeather(null);

      try {
        const response = await fetch(`/api/weather?location=${location}`);
        if (!response.ok) {
          throw new Error(`Failed to fetch weather data: ${response.status}`);
        }
        const weatherData = await response.json();
        const suitableCrops = getSuitableCrops(weatherData.main.temp, weatherData.main.humidity);

        setWeather({
          location: location,
          temperature: weatherData.main.temp,
          description: weatherData.weather[0].description,
          humidity: weatherData.main.humidity,
          windSpeed: weatherData.wind.speed,
          suitableCrops: suitableCrops,
        });
      } catch (err: any) {
        setError(err.message || "Failed to fetch weather data.");
      } finally {
        setLoading(false);
      }
  };

  return (
    <div>
      <h1>Weather Information</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Enter location (e.g., city)"
          value={location}
          onChange={(e) => setLocation(e.target.value)}
        />
        <button type="submit" disabled={loading}>
          {loading ? "Loading..." : "Get Weather"}
        </button>
      </form>

      {loading && <p>Loading weather data...</p>}
      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      {weather && (
        <div style={getWeatherContainerStyle(weather.description)}>
          <h2>Weather in {weather.location}</h2>
          <p>Temperature: {weather.temperature}°C</p>
          <p>Description: {weather.description}</p>
          <p>Humidity: {weather.humidity}%</p>
          <p>Wind Speed: {weather.windSpeed} m/s</p>
          <h3>Suitable Crops:</h3>
          <ul>
            {weather.suitableCrops.map((crop, index) => (
              <li key={index}>{crop}</li>
            ))}
          </ul>
        </div>
      )}

      {!loading && !error && !weather && (
        <p>Enter a location to get weather information.</p>
      )}
    </div>
  );
};

export default WeatherScreen;