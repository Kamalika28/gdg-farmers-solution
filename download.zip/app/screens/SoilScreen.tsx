"use client";

import { useState } from "react";
import { SoilData, SoilRecommendation } from "../models/SoilModel";


const soilScreenStyles = {
  container: { backgroundColor: "#F2E6D0", padding: "20px" },
  heading: { color: "#A0522D" },
  text: { color: "#734A12" },
};


import { getRecommendations } from "../services/SoilService";

const SoilScreen = () => {
  const [soilData, setSoilData] = useState<SoilData>({
    soilType: "Loamy", // Default value
    soilMoisture: 50, // Default value
    phLevel: 6.5, // Default value
  });
  const [recommendations, setRecommendations] = useState<
    SoilRecommendation | null
  >(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setSoilData({
      ...soilData,
      [name]: name === "soilType" ? value : parseFloat(value),
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const result = await getRecommendations(soilData);
      setRecommendations(result);
    } catch (err: any) {
      setError(err.message || "Error fetching recommendations");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={soilScreenStyles.container}>
      <h1 style={soilScreenStyles.heading}>Soil Analysis and Crop Recommendations</h1>

      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="soilType">Soil Type:</label>
          <select
            id="soilType"
            name="soilType"
            value={soilData.soilType}
            onChange={handleChange}
          >
            <option value="Sandy">Sandy</option>
            <option value="Clay">Clay</option>
            <option value="Loamy">Loamy</option>
            <option value="Silty">Silty</option>
            <option value="Peaty">Peaty</option>
            <option value="Chalky">Chalky</option>
          </select>
        </div>

        <div>
          <label htmlFor="soilMoisture">Soil Moisture Level (0-100):</label>
          <input
            type="number"
            id="soilMoisture"
            name="soilMoisture"
            min="0"
            max="100"
            value={soilData.soilMoisture}
            onChange={handleChange}
          />
        </div>

        <div>
          <label htmlFor="phLevel">pH Level (0-14):</label>
          <input
            type="number"
            id="phLevel"
            name="phLevel"
            min="0"
            max="14"
            step="0.1"
            value={soilData.phLevel}
            onChange={handleChange}
          />
        </div>

        <button type="submit" disabled={loading}>
          Get Recommendations
        </button>
      </form>

      {loading && <p>Loading recommendations...</p>}

      {error && <p style={{ color: "red" }}>Error: {error}</p>}

      {recommendations && (
        <div style={soilScreenStyles.text}>
          <h2 style={soilScreenStyles.heading}>Your Soil Data:</h2>
          <p >Soil Type: {soilData.soilType}</p>
          <p >Soil Moisture: {soilData.soilMoisture}%</p>
          <p >pH Level: {soilData.phLevel}</p>

          <h2 style={soilScreenStyles.heading}>Recommended Crops:</h2>
          {recommendations.recommendations.length > 0 ?(
            <ul>
              {recommendations.recommendations.map((crop, index) => (
                <li key={index}>{crop}</li>
              ))}
            </ul>
          ) : (
            <p>No specific recommendations found for this soil data.</p>
          )}
        </div>
      )}
    </div>
  );
};

export default SoilScreen;