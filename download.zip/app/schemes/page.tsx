"use client";

import styles from './Schemes.module.css';
import { useState, useEffect } from 'react';

interface Scheme {
  name: string;
  description: string;
  eligibility: string;
  benefits: string;
  application: string;
}

interface CountryData {
  country: string;
  schemes: Scheme[];
}

const SchemesPage = () => {
  const [schemesData, setSchemesData] = useState<CountryData[]>([]);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('/schemes.json'); // Assuming schemes.json is in the public directory
        if (!response.ok) {
          throw new Error('Failed to fetch schemes data');
        }
        const data: CountryData[] = await response.json();
        setSchemesData(data);
      } catch (error) {
        console.error('Error fetching schemes data:', error);
        // Handle error appropriately, e.g., display an error message
      }
    };

    fetchData();
  }, []);

  const handleCountryChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCountry(event.target.value);
  };

    const countryOptions = schemesData.map((countryData) => countryData.country);

  const filteredSchemesData = selectedCountry
    ? schemesData.filter((countryData) => countryData.country === selectedCountry)
    : schemesData;

  return (
    <div>
      <h1>Government Schemes Information</h1>

      <select value={selectedCountry || ''} onChange={handleCountryChange}>
        <option value="">Select Country (All)</option>
        {countryOptions.map((countryName) => (
          <option key={countryName} value={countryName}>
            {countryName}
          </option>
        ))}
      </select>

      {filteredSchemesData.map((countryData, countryIndex) => (
        <div key={countryIndex} className={`${styles[`${countryData.country.toLowerCase().replace(/ /g, '-')}-section`]}`} >

          <h2>{countryData.country}</h2>
          {countryData.schemes.map((scheme, schemeIndex) => (
            <div key={schemeIndex}>
              <h3>{scheme.name}</h3>
              <p><strong>Description:</strong> {scheme.description}</p>
              <p><strong>Eligibility:</strong> {scheme.eligibility}</p>
              <p><strong>Benefits:</strong> {scheme.benefits}</p>
              <p><strong>Application:</strong> {scheme.application}</p>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
};

export default SchemesPage;