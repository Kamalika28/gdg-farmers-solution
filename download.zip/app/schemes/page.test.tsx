import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';

import SchemesPage from './page';

// Declare and initialize mockSchemesData before jest.mock
const mockSchemesData = [
  {
    country: 'TestCountry2',
    schemes: [
      { name: 'TestScheme3', description: 'TestDescription3' },
      { name: 'TestScheme4', description: 'TestDescription4' },
    ],
  },
  
  
];
const mockSchemesData2 = [
    {
    country: 'TestCountry',
    schemes: [
      { name: 'TestScheme1', description: 'TestDescription1' },
      { name: 'TestScheme2', description: 'TestDescription2' },
    ],
  },
  
  
];

 


jest.mock('../schemes.json', () => mockSchemesData);


describe('SchemesPage', () => {
    beforeEach(() => {
        global.fetch = jest.fn(() =>
            Promise.resolve({
                json: () => Promise.resolve(mockSchemesData2),
            })
        ) as jest.Mock;
    });
  it('renders the component', () => {
    render(<SchemesPage />);
    expect(screen.getByText('Government Schemes Information')).toBeInTheDocument();
  });
    
    it('displays schemes data', async () => {

  it('displays schemes data', () => {
    render(<SchemesPage />);

    schemesData.forEach((countryData) => {
        
        countryData.schemes.forEach((scheme) => {
            expect(screen.getByText(scheme.name)).toBeInTheDocument();
      });
    });
  });

  it('filters schemes by country', () => {
    render(<SchemesPage />);

    const select = screen.getByRole('combobox');
    fireEvent.change(select, { target: { value: mockSchemesData2[0].country } });
    mockSchemesData2[0].schemes.forEach((scheme) => {
        expect(screen.getByText(scheme.name)).toBeInTheDocument();
    });
    
  });
});
