export const modernFarmingTechniques = [
  {
    country: "India",
    techniques: [
      {
        title: "Precision Agriculture",
        description: "Using technology like GPS, sensors, and drones to optimize inputs and improve yields.",
      },
      {
        title: "Drip Irrigation",
        description: "Delivering water directly to plant roots, conserving water and improving efficiency.",
      },
      {
        title: "Protected Cultivation (Polyhouses/Greenhouses)",
        description: "Growing crops in controlled environments to protect them from weather and pests.",
      },
      {
        title: "Integrated Pest Management (IPM)",
        description: "Using a combination of biological, cultural, and chemical methods to control pests sustainably.",
      },
    ],
  },
  {
    country: "US",
    techniques: [
      {
        title: "GPS-Guided Farming",
        description: "Using GPS technology for precise field mapping, variable-rate applications, and automated machinery.",
      },
      {
        title: "Vertical Farming",
        description: "Growing crops in stacked layers in controlled indoor environments, maximizing space and resource efficiency.",
      },
      {
        title: "Robotics in Agriculture",
        description: "Using robots for tasks like planting, weeding, harvesting, and livestock management.",
      },
      {
        title: "Data Analytics and AI",
        description: "Analyzing farm data to optimize decision-making and improve crop yields and resource management.",
      },
    ],
  },
  {
    country: "UK",
    techniques: [
      {
        title: "Controlled Environment Agriculture (CEA)",
        description: "Using greenhouses and vertical farms to control temperature, humidity, and light for optimal crop growth.",
      },
      {
        title: "Regenerative Agriculture",
        description: "Focusing on soil health, biodiversity, and carbon sequestration to create sustainable farming systems.",
      },
      {
        title: "Agri-Tech and Smart Farming",
        description: "Using IoT sensors, drones, and data analytics to monitor and optimize farm operations.",
      },
      {
        title: "Precision Livestock Farming",
        description: "Using technology to monitor and manage livestock health, welfare, and productivity.",
      },
    ],
  },
];