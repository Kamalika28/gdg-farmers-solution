import SoilScreen from '../screens/SoilScreen';

export default function SoilPage() {
  return <SoilScreen />;
}