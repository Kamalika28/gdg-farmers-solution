import WeatherScreen from '../screens/WeatherScreen';

export default function WeatherPage() {
  return <WeatherScreen />;
}